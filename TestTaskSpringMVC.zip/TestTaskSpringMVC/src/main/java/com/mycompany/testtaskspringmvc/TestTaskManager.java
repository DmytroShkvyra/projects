/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.testtaskspringmvc;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author USer
 */
@Component
public class TestTaskManager implements ITestTaskManager {

    private static final Logger logger = LoggerFactory
	    .getLogger(TestTaskManager.class);
    private SessionFactory sessionFactory;

    public TestTaskManager() {
    }

    public SessionFactory getSessionFactory() {
	return sessionFactory;
    }

    @Autowired
    public void setSessionFactory(SessionFactory sessionFactory) {
	logger.debug("SessionFactory = " + sessionFactory);
	this.sessionFactory = sessionFactory;
    }

    public TestTaskManager(SessionFactory sessionFactory) {
	logger.debug("Constructor  TestTaskManager SessionFactory = " + sessionFactory);
	this.sessionFactory = sessionFactory;
    }

    @Override
    @Transactional
    public void update(TestTask task) {
	getCurrentSession().update(task);
    }

    @Override
    @Transactional
    public Integer addTask(TestTask task) {
	getCurrentSession().persist(task);
	logger.debug("new taskid = "+task.getEntityId());
	return task.getEntityId();
    }

    @Override
    @Transactional
    public void removeTask(Integer id) {
	String hqlDelete = "delete TestTask t where t.entityId = :id";
	int deletedEntities = getCurrentSession().createQuery( hqlDelete )
        .setInteger( "id", id ).executeUpdate();
	logger.debug("removed "+ deletedEntities +" tasks");
    }

    @Override
    @Transactional(readOnly = true)
    @SuppressWarnings("unchecked")
    public List<TestTask> getAllTasks() {
	return getCurrentSession().createQuery("from TestTask").list();
    }

    @Override
    @Transactional(readOnly = true)
    public TestTask getTask(Integer id) {
	String hql = "from TestTask as task where task.entityId = :id";
	List<TestTask> res = getCurrentSession().createQuery( hql ).setInteger( "id", id ).list();
	return (res.size()>0)? res.get(0): null;
    }

    /**
     * Returns the session associated with the ongoing reward transaction.
     *
     * @return the transactional session
     */
    protected Session getCurrentSession() {
	return sessionFactory.getCurrentSession();
    }
}
