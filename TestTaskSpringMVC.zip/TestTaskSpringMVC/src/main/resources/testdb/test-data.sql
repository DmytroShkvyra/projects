
insert into T_TASK (STATUS, NAME) values ('not started', 'Spring WEB и любые шаблоны на выбор (JSP/JSTL, Velocity, FreeMarker, etc), приветствуется Apache Tiles');
insert into T_TASK (STATUS, NAME) values ('not started', 'Spring Security');
insert into T_TASK (STATUS, NAME) values ('not started', 'Любой ORM фрэймворк на выбор (Open JPA, Hibername, TopLink, etc)');
insert into T_TASK (STATUS, NAME) values ('not started', 'log4j/slf4j');
insert into T_TASK (STATUS, NAME) values ('not started', 'Автоматизация сборки на maven/ant (на выбор)');
insert into T_TASK (STATUS, NAME) values ('not started', 'Наличие unit-тестов (JUnit/TestNG)');
insert into T_TASK (STATUS, NAME) values ('not started', 'База данных для теста - H2 или HSQL (InMemory)');
insert into T_TASK (STATUS, NAME) values ('not started', 'Task3');
insert into T_TASK (STATUS, NAME) values ('not started', 'Task4');
insert into T_TASK (STATUS, NAME) values ('not started', 'Task5');
